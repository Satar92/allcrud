<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;

class HomeController extends AbstractController
{
    // #[Route('/', name: 'app_home')]
    public function index(): Response
    {
        $tabSimple = [1,2,3,4,5];

        $tab = [
            'prop1' => 'val1',
            'prop2' => 'val2',
            'prop3' => 4,
            'prop4' => false,
        ];

        $maVar = "Hello world";

        $monObj = new \stdClass;
        $monObj->propriete1 = "prop1 de mon objet";
        $monObj->fonction = function(){
            return "Méthode de mon Objet";
        };

        $today = \date('');

        return $this->render('home/index.html.twig', [
            'tabSimple' => $tabSimple,
            'monTab' => $tab,
            'maVar' => $maVar,
            'obj' => $monObj,
            'today' => $today,
        ]);
    }
}
