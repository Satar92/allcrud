<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

class BlogController extends AbstractController
{
    #[Route('/blog', name: 'app_blog')]
    public function index(): Response
    {
        return $this->render('blog/index.html.twig', [
            'controller_name' => 'BlogController',
        ]);
    }

    public function show(int $id, Request $req): Response 
    {
        // recuperer le nom interne de la route:
        $routeName = $req->attributes->get('_route');
        $routeParameters = $req->attributes->get('_route_params');
        // dd($routeName);
        // dd($routeParameters);      

        return new Response(
            '<html>
                <body>
                    <p> Voici le post numéro ' . $id . '</p>
                </body>
            </html>'
        ); 
    }

    public function edit(int $id): Response 
    {
        return new Response(
            '<html>
                <body>
                    <p> Nous éditons le post n° ' . $id . '</p>
                </body>
            </html>'
        ); 
    }

    public function list(): Response
    {
        // generation d'url

        // generation d'url à partir d'une route sans paramètres
        $url_vers_tirage_keno = $this->generateUrl('app_tirage_keno');
        // dd($url_vers_tirage_keno);

        // url avec paramètres
        $url_vers_tirage_aleatoire = $this->generateUrl('app_tirage_aleatoire', [
            'nom_du_jeu' => 'Amigo',
            'num_tires' => 6,
            'num_total' => 25
        ]);
        //dd($url_vers_tirage_aleatoire);

        // url absolue route simple
        $url_absolue_vers_tirage_keno = $this->generateUrl('app_tirage_keno', [], UrlGeneratorInterface::ABSOLUTE_URL);
        //dd($url_absolue_vers_tirage_keno);

        // url absolue avec paramètres
        $url_absolue_vers_tirage_aleatoire = $this->generateUrl('app_tirage_aleatoire', [
            'nom_du_jeu' => 'Amigo',
            'num_tires' => 6,
            'num_total' => 25
        ], UrlGeneratorInterface::ABSOLUTE_URL);
        dd($url_absolue_vers_tirage_aleatoire);
    }
}
