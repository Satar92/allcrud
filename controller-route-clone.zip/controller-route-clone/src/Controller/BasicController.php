<?php

namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;

class BasicController
{
    // #[Route('/controller/{controllerName}', name: 'app_basic_controller')]
    public function index(string $controllerName): Response
    {
        return new Response('
            <html>
                <head></head>
                <body>
                    <h1>Je suis le  ' . $controllerName . '</h1>
                </body>
            </html>
        ');
    }
}
