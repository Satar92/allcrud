<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;

class EvolvedController extends AbstractController
{
    // #[Route('/evolved/controller/{controllerName}', name: 'app_evolved_controller')]
    public function index(string $controllerName): Response
    {
        return $this->render('evolved/index.html.twig', [
            'controller_name' => $controllerName,
            'tralalatsointsoin' => 'tralalatsointsoin',
        ]);
    }
}
